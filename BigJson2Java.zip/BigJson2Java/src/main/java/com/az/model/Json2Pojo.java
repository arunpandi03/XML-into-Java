package com.az.model;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Envelope"
})

public class Json2Pojo {

    @JsonProperty("Envelope")
    private Envelope envelope;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public Json2Pojo() {
    }

    /**
     * 
     * @param envelope
     */
    public Json2Pojo(Envelope envelope) {
        super();
        this.envelope = envelope;
    }

    @JsonProperty("Envelope")
    public Envelope getEnvelope() {
        return envelope;
    }

    @JsonProperty("Envelope")
    public void setEnvelope(Envelope envelope) {
        this.envelope = envelope;
    }

    public Json2Pojo withEnvelope(Envelope envelope) {
        this.envelope = envelope;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Json2Pojo withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

	@Override
	public String toString() {
		return "Json2Pojo [envelope=" + envelope + ", additionalProperties=" + additionalProperties + "]";
	}

}
