package com.az.model;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SegmentType",
    "SegmentValue"
})

public class Segmentation {

    @JsonProperty("SegmentType")
    private String segmentType;
    @JsonProperty("SegmentValue")
    private String segmentValue;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public Segmentation() {
    }

    /**
     * 
     * @param segmentValue
     * @param segmentType
     */
    public Segmentation(String segmentType, String segmentValue) {
        super();
        this.segmentType = segmentType;
        this.segmentValue = segmentValue;
    }

    @JsonProperty("SegmentType")
    public String getSegmentType() {
        return segmentType;
    }

    @JsonProperty("SegmentType")
    public void setSegmentType(String segmentType) {
        this.segmentType = segmentType;
    }

    public Segmentation withSegmentType(String segmentType) {
        this.segmentType = segmentType;
        return this;
    }

    @JsonProperty("SegmentValue")
    public String getSegmentValue() {
        return segmentValue;
    }

    @JsonProperty("SegmentValue")
    public void setSegmentValue(String segmentValue) {
        this.segmentValue = segmentValue;
    }

    public Segmentation withSegmentValue(String segmentValue) {
        this.segmentValue = segmentValue;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Segmentation withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

	@Override
	public String toString() {
		return "Segmentation [segmentType=" + segmentType + ", segmentValue=" + segmentValue + ", additionalProperties="
				+ additionalProperties + "]";
	}

}
