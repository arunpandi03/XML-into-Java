package com.az.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SCB_CustClass",
    "SCB_ApplScore",
    "SCB_MMCycleDue",
    "AcctRec",
    "PersonPartyInfo",
    "SCBFlag"
})

public class SCBCustomerEnquiry {

    @JsonProperty("SCB_CustClass")
    private String sCBCustClass;
    @JsonProperty("SCB_ApplScore")
    private Long sCBApplScore;
    @JsonProperty("SCB_MMCycleDue")
    private Long sCBMMCycleDue;
    @JsonProperty("AcctRec")
    private AcctRec acctRec;
    @JsonProperty("PersonPartyInfo")
    private PersonPartyInfo personPartyInfo;
    @JsonProperty("SCBFlag")
    private SCBFlag sCBFlag;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public SCBCustomerEnquiry() {
    }

    /**
     * 
     * @param sCBApplScore
     * @param sCBCustClass
     * @param acctRec
     * @param personPartyInfo
     * @param sCBFlag
     * @param sCBMMCycleDue
     */
    public SCBCustomerEnquiry(String sCBCustClass, Long sCBApplScore, Long sCBMMCycleDue, AcctRec acctRec, PersonPartyInfo personPartyInfo, SCBFlag sCBFlag) {
        super();
        this.sCBCustClass = sCBCustClass;
        this.sCBApplScore = sCBApplScore;
        this.sCBMMCycleDue = sCBMMCycleDue;
        this.acctRec = acctRec;
        this.personPartyInfo = personPartyInfo;
        this.sCBFlag = sCBFlag;
    }

    @JsonProperty("SCB_CustClass")
    public String getSCBCustClass() {
        return sCBCustClass;
    }

    @JsonProperty("SCB_CustClass")
    public void setSCBCustClass(String sCBCustClass) {
        this.sCBCustClass = sCBCustClass;
    }

    public SCBCustomerEnquiry withSCBCustClass(String sCBCustClass) {
        this.sCBCustClass = sCBCustClass;
        return this;
    }

    @JsonProperty("SCB_ApplScore")
    public Long getSCBApplScore() {
        return sCBApplScore;
    }

    @JsonProperty("SCB_ApplScore")
    public void setSCBApplScore(Long sCBApplScore) {
        this.sCBApplScore = sCBApplScore;
    }

    public SCBCustomerEnquiry withSCBApplScore(Long sCBApplScore) {
        this.sCBApplScore = sCBApplScore;
        return this;
    }

    @JsonProperty("SCB_MMCycleDue")
    public Long getSCBMMCycleDue() {
        return sCBMMCycleDue;
    }

    @JsonProperty("SCB_MMCycleDue")
    public void setSCBMMCycleDue(Long sCBMMCycleDue) {
        this.sCBMMCycleDue = sCBMMCycleDue;
    }

    public SCBCustomerEnquiry withSCBMMCycleDue(Long sCBMMCycleDue) {
        this.sCBMMCycleDue = sCBMMCycleDue;
        return this;
    }

    @JsonProperty("AcctRec")
    public AcctRec getAcctRec() {
        return acctRec;
    }

    @JsonProperty("AcctRec")
    public void setAcctRec(AcctRec acctRec) {
        this.acctRec = acctRec;
    }

    public SCBCustomerEnquiry withAcctRec(AcctRec acctRec) {
        this.acctRec = acctRec;
        return this;
    }

    @JsonProperty("PersonPartyInfo")
    public PersonPartyInfo getPersonPartyInfo() {
        return personPartyInfo;
    }

    @JsonProperty("PersonPartyInfo")
    public void setPersonPartyInfo(PersonPartyInfo personPartyInfo) {
        this.personPartyInfo = personPartyInfo;
    }

    public SCBCustomerEnquiry withPersonPartyInfo(PersonPartyInfo personPartyInfo) {
        this.personPartyInfo = personPartyInfo;
        return this;
    }

    @JsonProperty("SCBFlag")
    public SCBFlag getSCBFlag() {
        return sCBFlag;
    }

    @JsonProperty("SCBFlag")
    public void setSCBFlag(SCBFlag sCBFlag) {
        this.sCBFlag = sCBFlag;
    }

    public SCBCustomerEnquiry withSCBFlag(SCBFlag sCBFlag) {
        this.sCBFlag = sCBFlag;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public SCBCustomerEnquiry withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

	@Override
	public String toString() {
		return "SCBCustomerEnquiry [sCBCustClass=" + sCBCustClass + ", sCBApplScore=" + sCBApplScore
				+ ", sCBMMCycleDue=" + sCBMMCycleDue + ", acctRec=" + acctRec + ", personPartyInfo=" + personPartyInfo
				+ ", sCBFlag=" + sCBFlag + ", additionalProperties=" + additionalProperties + "]";
	}

}
