
package com.az.model;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "AcctAmtType",
    "Amt",
    "SCB_AgingCode",
    "EffDt"
})

public class AcctPeriodDatum {

    @JsonProperty("AcctAmtType")
    private String acctAmtType;
    @JsonProperty("Amt")
    private Long amt;
    @JsonProperty("SCB_AgingCode")
    private String sCBAgingCode;
    @JsonProperty("EffDt")
    private String effDt;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public AcctPeriodDatum() {
    }

    /**
     * 
     * @param acctAmtType
     * @param sCBAgingCode
     * @param amt
     * @param effDt
     */
    public AcctPeriodDatum(String acctAmtType, Long amt, String sCBAgingCode, String effDt) {
        super();
        this.acctAmtType = acctAmtType;
        this.amt = amt;
        this.sCBAgingCode = sCBAgingCode;
        this.effDt = effDt;
    }

    @JsonProperty("AcctAmtType")
    public String getAcctAmtType() {
        return acctAmtType;
    }

    @JsonProperty("AcctAmtType")
    public void setAcctAmtType(String acctAmtType) {
        this.acctAmtType = acctAmtType;
    }

    public AcctPeriodDatum withAcctAmtType(String acctAmtType) {
        this.acctAmtType = acctAmtType;
        return this;
    }

    @JsonProperty("Amt")
    public Long getAmt() {
        return amt;
    }

    @JsonProperty("Amt")
    public void setAmt(Long amt) {
        this.amt = amt;
    }

    public AcctPeriodDatum withAmt(Long amt) {
        this.amt = amt;
        return this;
    }

    @JsonProperty("SCB_AgingCode")
    public String getSCBAgingCode() {
        return sCBAgingCode;
    }

    @JsonProperty("SCB_AgingCode")
    public void setSCBAgingCode(String sCBAgingCode) {
        this.sCBAgingCode = sCBAgingCode;
    }

    public AcctPeriodDatum withSCBAgingCode(String sCBAgingCode) {
        this.sCBAgingCode = sCBAgingCode;
        return this;
    }

    @JsonProperty("EffDt")
    public String getEffDt() {
        return effDt;
    }

    @JsonProperty("EffDt")
    public void setEffDt(String effDt) {
        this.effDt = effDt;
    }

    public AcctPeriodDatum withEffDt(String effDt) {
        this.effDt = effDt;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AcctPeriodDatum withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

	@Override
	public String toString() {
		return "AcctPeriodDatum [acctAmtType=" + acctAmtType + ", amt=" + amt + ", sCBAgingCode=" + sCBAgingCode
				+ ", effDt=" + effDt + ", additionalProperties=" + additionalProperties + "]";
	}

}
