
package com.az.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "header",
    "getLoanListInquiryResPayload"
})

public class GetLoanListInquiryResponse__1 {

    @JsonProperty("header")
    private Header header;
    @JsonProperty("getLoanListInquiryResPayload")
    private GetLoanListInquiryResPayload getLoanListInquiryResPayload;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public GetLoanListInquiryResponse__1() {
    }

    /**
     * 
     * @param header
     * @param getLoanListInquiryResPayload
     */
    public GetLoanListInquiryResponse__1(Header header, GetLoanListInquiryResPayload getLoanListInquiryResPayload) {
        super();
        this.header = header;
        this.getLoanListInquiryResPayload = getLoanListInquiryResPayload;
    }

    @JsonProperty("header")
    public Header getHeader() {
        return header;
    }

    @JsonProperty("header")
    public void setHeader(Header header) {
        this.header = header;
    }

    public GetLoanListInquiryResponse__1 withHeader(Header header) {
        this.header = header;
        return this;
    }

    @JsonProperty("getLoanListInquiryResPayload")
    public GetLoanListInquiryResPayload getGetLoanListInquiryResPayload() {
        return getLoanListInquiryResPayload;
    }

    @JsonProperty("getLoanListInquiryResPayload")
    public void setGetLoanListInquiryResPayload(GetLoanListInquiryResPayload getLoanListInquiryResPayload) {
        this.getLoanListInquiryResPayload = getLoanListInquiryResPayload;
    }

    public GetLoanListInquiryResponse__1 withGetLoanListInquiryResPayload(GetLoanListInquiryResPayload getLoanListInquiryResPayload) {
        this.getLoanListInquiryResPayload = getLoanListInquiryResPayload;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public GetLoanListInquiryResponse__1 withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

	@Override
	public String toString() {
		return "GetLoanListInquiryResponse__1 [header=" + header + ", getLoanListInquiryResPayload="
				+ getLoanListInquiryResPayload + ", additionalProperties=" + additionalProperties + "]";
	}

}
