package com.az.model;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "subTypeName"
})

public class SubType {

    @JsonProperty("subTypeName")
    private String subTypeName;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public SubType() {
    }

    /**
     * 
     * @param subTypeName
     */
    public SubType(String subTypeName) {
        super();
        this.subTypeName = subTypeName;
    }

    @JsonProperty("subTypeName")
    public String getSubTypeName() {
        return subTypeName;
    }

    @JsonProperty("subTypeName")
    public void setSubTypeName(String subTypeName) {
        this.subTypeName = subTypeName;
    }

    public SubType withSubTypeName(String subTypeName) {
        this.subTypeName = subTypeName;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public SubType withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

	@Override
	public String toString() {
		return "SubType [subTypeName=" + subTypeName + ", additionalProperties=" + additionalProperties + "]";
	}

}
