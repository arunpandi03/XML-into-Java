package com.az.model;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "StatusCode",
    "StatusDesc"
})

public class Status {

    @JsonProperty("StatusCode")
    private Long statusCode;
    @JsonProperty("StatusDesc")
    private String statusDesc;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public Status() {
    }

    /**
     * 
     * @param statusDesc
     * @param statusCode
     */
    public Status(Long statusCode, String statusDesc) {
        super();
        this.statusCode = statusCode;
        this.statusDesc = statusDesc;
    }

    @JsonProperty("StatusCode")
    public Long getStatusCode() {
        return statusCode;
    }

    @JsonProperty("StatusCode")
    public void setStatusCode(Long statusCode) {
        this.statusCode = statusCode;
    }

    public Status withStatusCode(Long statusCode) {
        this.statusCode = statusCode;
        return this;
    }

    @JsonProperty("StatusDesc")
    public String getStatusDesc() {
        return statusDesc;
    }

    @JsonProperty("StatusDesc")
    public void setStatusDesc(String statusDesc) {
        this.statusDesc = statusDesc;
    }

    public Status withStatusDesc(String statusDesc) {
        this.statusDesc = statusDesc;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Status withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

	@Override
	public String toString() {
		return "Status [statusCode=" + statusCode + ", statusDesc=" + statusDesc + ", additionalProperties="
				+ additionalProperties + "]";
	}

}
