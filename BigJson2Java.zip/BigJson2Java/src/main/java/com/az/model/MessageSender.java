package com.az.model;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "messageSender",
    "senderDomain",
    "countryCode"
})
public class MessageSender {

    @JsonProperty("messageSender")
    private String messageSender;
    @JsonProperty("senderDomain")
    private SenderDomain senderDomain;
    @JsonProperty("countryCode")
    private String countryCode;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public MessageSender() {
    }

    /**
     * 
     * @param countryCode
     * @param messageSender
     * @param senderDomain
     */
    public MessageSender(String messageSender, SenderDomain senderDomain, String countryCode) {
        super();
        this.messageSender = messageSender;
        this.senderDomain = senderDomain;
        this.countryCode = countryCode;
    }

    @JsonProperty("messageSender")
    public String getMessageSender() {
        return messageSender;
    }

    @JsonProperty("messageSender")
    public void setMessageSender(String messageSender) {
        this.messageSender = messageSender;
    }

    public MessageSender withMessageSender(String messageSender) {
        this.messageSender = messageSender;
        return this;
    }

    @JsonProperty("senderDomain")
    public SenderDomain getSenderDomain() {
        return senderDomain;
    }

    @JsonProperty("senderDomain")
    public void setSenderDomain(SenderDomain senderDomain) {
        this.senderDomain = senderDomain;
    }

    public MessageSender withSenderDomain(SenderDomain senderDomain) {
        this.senderDomain = senderDomain;
        return this;
    }

    @JsonProperty("countryCode")
    public String getCountryCode() {
        return countryCode;
    }

    @JsonProperty("countryCode")
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public MessageSender withCountryCode(String countryCode) {
        this.countryCode = countryCode;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public MessageSender withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

	@Override
	public String toString() {
		return "MessageSender [messageSender=" + messageSender + ", senderDomain=" + senderDomain + ", countryCode="
				+ countryCode + ", additionalProperties=" + additionalProperties + "]";
	}

}
