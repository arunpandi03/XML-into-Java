package com.az.model;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Header",
    "Body"
})
public class Envelope {

    @JsonProperty("Header")
    private String header;
    @JsonProperty("Body")
    private Body body;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public Envelope() {
    }

    /**
     * 
     * @param header
     * @param body
     */
    public Envelope(String header, Body body) {
        super();
        this.header = header;
        this.body = body;
    }

    @JsonProperty("Header")
    public String getHeader() {
        return header;
    }

    @JsonProperty("Header")
    public void setHeader(String header) {
        this.header = header;
    }

    public Envelope withHeader(String header) {
        this.header = header;
        return this;
    }

    @JsonProperty("Body")
    public Body getBody() {
        return body;
    }

    @JsonProperty("Body")
    public void setBody(Body body) {
        this.body = body;
    }

    public Envelope withBody(Body body) {
        this.body = body;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Envelope withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

	@Override
	public String toString() {
		return "Envelope [header=" + header + ", body=" + body + ", additionalProperties=" + additionalProperties + "]";
	}

}
