
package com.az.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "payloadFormat",
    "payloadVersion",
    "getLoanListInquiryRes"
})

public class GetLoanListInquiryResPayload {

    @JsonProperty("payloadFormat")
    private String payloadFormat;
    @JsonProperty("payloadVersion")
    private Long payloadVersion;
    @JsonProperty("getLoanListInquiryRes")
    private GetLoanListInquiryRes getLoanListInquiryRes;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public GetLoanListInquiryResPayload() {
    }

    /**
     * 
     * @param payloadVersion
     * @param getLoanListInquiryRes
     * @param payloadFormat
     */
    public GetLoanListInquiryResPayload(String payloadFormat, Long payloadVersion, GetLoanListInquiryRes getLoanListInquiryRes) {
        super();
        this.payloadFormat = payloadFormat;
        this.payloadVersion = payloadVersion;
        this.getLoanListInquiryRes = getLoanListInquiryRes;
    }

    @JsonProperty("payloadFormat")
    public String getPayloadFormat() {
        return payloadFormat;
    }

    @JsonProperty("payloadFormat")
    public void setPayloadFormat(String payloadFormat) {
        this.payloadFormat = payloadFormat;
    }

    public GetLoanListInquiryResPayload withPayloadFormat(String payloadFormat) {
        this.payloadFormat = payloadFormat;
        return this;
    }

    @JsonProperty("payloadVersion")
    public Long getPayloadVersion() {
        return payloadVersion;
    }

    @JsonProperty("payloadVersion")
    public void setPayloadVersion(Long payloadVersion) {
        this.payloadVersion = payloadVersion;
    }

    public GetLoanListInquiryResPayload withPayloadVersion(Long payloadVersion) {
        this.payloadVersion = payloadVersion;
        return this;
    }

    @JsonProperty("getLoanListInquiryRes")
    public GetLoanListInquiryRes getGetLoanListInquiryRes() {
        return getLoanListInquiryRes;
    }

    @JsonProperty("getLoanListInquiryRes")
    public void setGetLoanListInquiryRes(GetLoanListInquiryRes getLoanListInquiryRes) {
        this.getLoanListInquiryRes = getLoanListInquiryRes;
    }

    public GetLoanListInquiryResPayload withGetLoanListInquiryRes(GetLoanListInquiryRes getLoanListInquiryRes) {
        this.getLoanListInquiryRes = getLoanListInquiryRes;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public GetLoanListInquiryResPayload withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

	@Override
	public String toString() {
		return "GetLoanListInquiryResPayload [payloadFormat=" + payloadFormat + ", payloadVersion=" + payloadVersion
				+ ", getLoanListInquiryRes=" + getLoanListInquiryRes + ", additionalProperties=" + additionalProperties
				+ "]";
	}

}
