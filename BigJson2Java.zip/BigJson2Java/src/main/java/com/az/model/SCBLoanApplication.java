
package com.az.model;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SCB_Product",
    "SCB_SubProductCode",
    "SCB_AppAmt",
    "SCB_AppDt",
    "SCB_ApprovedDt",
    "SCB_DueCycleDay",
    "SCB_ProduceStmt",
    "SCB_RepaymentSchedule"
})

public class SCBLoanApplication {

    @JsonProperty("SCB_Product")
    private Long sCBProduct;
    @JsonProperty("SCB_SubProductCode")
    private String sCBSubProductCode;
    @JsonProperty("SCB_AppAmt")
    private Long sCBAppAmt;
    @JsonProperty("SCB_AppDt")
    private String sCBAppDt;
    @JsonProperty("SCB_ApprovedDt")
    private String sCBApprovedDt;
    @JsonProperty("SCB_DueCycleDay")
    private Long sCBDueCycleDay;
    @JsonProperty("SCB_ProduceStmt")
    private Long sCBProduceStmt;
    @JsonProperty("SCB_RepaymentSchedule")
    private Long sCBRepaymentSchedule;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public SCBLoanApplication() {
    }

    /**
     * 
     * @param sCBProduceStmt
     * @param sCBApprovedDt
     * @param sCBDueCycleDay
     * @param sCBProduct
     * @param sCBAppAmt
     * @param sCBRepaymentSchedule
     * @param sCBSubProductCode
     * @param sCBAppDt
     */
    public SCBLoanApplication(Long sCBProduct, String sCBSubProductCode, Long sCBAppAmt, String sCBAppDt, String sCBApprovedDt, Long sCBDueCycleDay, Long sCBProduceStmt, Long sCBRepaymentSchedule) {
        super();
        this.sCBProduct = sCBProduct;
        this.sCBSubProductCode = sCBSubProductCode;
        this.sCBAppAmt = sCBAppAmt;
        this.sCBAppDt = sCBAppDt;
        this.sCBApprovedDt = sCBApprovedDt;
        this.sCBDueCycleDay = sCBDueCycleDay;
        this.sCBProduceStmt = sCBProduceStmt;
        this.sCBRepaymentSchedule = sCBRepaymentSchedule;
    }

    @JsonProperty("SCB_Product")
    public Long getSCBProduct() {
        return sCBProduct;
    }

    @JsonProperty("SCB_Product")
    public void setSCBProduct(Long sCBProduct) {
        this.sCBProduct = sCBProduct;
    }

    public SCBLoanApplication withSCBProduct(Long sCBProduct) {
        this.sCBProduct = sCBProduct;
        return this;
    }

    @JsonProperty("SCB_SubProductCode")
    public String getSCBSubProductCode() {
        return sCBSubProductCode;
    }

    @JsonProperty("SCB_SubProductCode")
    public void setSCBSubProductCode(String sCBSubProductCode) {
        this.sCBSubProductCode = sCBSubProductCode;
    }

    public SCBLoanApplication withSCBSubProductCode(String sCBSubProductCode) {
        this.sCBSubProductCode = sCBSubProductCode;
        return this;
    }

    @JsonProperty("SCB_AppAmt")
    public Long getSCBAppAmt() {
        return sCBAppAmt;
    }

    @JsonProperty("SCB_AppAmt")
    public void setSCBAppAmt(Long sCBAppAmt) {
        this.sCBAppAmt = sCBAppAmt;
    }

    public SCBLoanApplication withSCBAppAmt(Long sCBAppAmt) {
        this.sCBAppAmt = sCBAppAmt;
        return this;
    }

    @JsonProperty("SCB_AppDt")
    public String getSCBAppDt() {
        return sCBAppDt;
    }

    @JsonProperty("SCB_AppDt")
    public void setSCBAppDt(String sCBAppDt) {
        this.sCBAppDt = sCBAppDt;
    }

    public SCBLoanApplication withSCBAppDt(String sCBAppDt) {
        this.sCBAppDt = sCBAppDt;
        return this;
    }

    @JsonProperty("SCB_ApprovedDt")
    public String getSCBApprovedDt() {
        return sCBApprovedDt;
    }

    @JsonProperty("SCB_ApprovedDt")
    public void setSCBApprovedDt(String sCBApprovedDt) {
        this.sCBApprovedDt = sCBApprovedDt;
    }

    public SCBLoanApplication withSCBApprovedDt(String sCBApprovedDt) {
        this.sCBApprovedDt = sCBApprovedDt;
        return this;
    }

    @JsonProperty("SCB_DueCycleDay")
    public Long getSCBDueCycleDay() {
        return sCBDueCycleDay;
    }

    @JsonProperty("SCB_DueCycleDay")
    public void setSCBDueCycleDay(Long sCBDueCycleDay) {
        this.sCBDueCycleDay = sCBDueCycleDay;
    }

    public SCBLoanApplication withSCBDueCycleDay(Long sCBDueCycleDay) {
        this.sCBDueCycleDay = sCBDueCycleDay;
        return this;
    }

    @JsonProperty("SCB_ProduceStmt")
    public Long getSCBProduceStmt() {
        return sCBProduceStmt;
    }

    @JsonProperty("SCB_ProduceStmt")
    public void setSCBProduceStmt(Long sCBProduceStmt) {
        this.sCBProduceStmt = sCBProduceStmt;
    }

    public SCBLoanApplication withSCBProduceStmt(Long sCBProduceStmt) {
        this.sCBProduceStmt = sCBProduceStmt;
        return this;
    }

    @JsonProperty("SCB_RepaymentSchedule")
    public Long getSCBRepaymentSchedule() {
        return sCBRepaymentSchedule;
    }

    @JsonProperty("SCB_RepaymentSchedule")
    public void setSCBRepaymentSchedule(Long sCBRepaymentSchedule) {
        this.sCBRepaymentSchedule = sCBRepaymentSchedule;
    }

    public SCBLoanApplication withSCBRepaymentSchedule(Long sCBRepaymentSchedule) {
        this.sCBRepaymentSchedule = sCBRepaymentSchedule;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public SCBLoanApplication withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

	@Override
	public String toString() {
		return "SCBLoanApplication [sCBProduct=" + sCBProduct + ", sCBSubProductCode=" + sCBSubProductCode
				+ ", sCBAppAmt=" + sCBAppAmt + ", sCBAppDt=" + sCBAppDt + ", sCBApprovedDt=" + sCBApprovedDt
				+ ", sCBDueCycleDay=" + sCBDueCycleDay + ", sCBProduceStmt=" + sCBProduceStmt
				+ ", sCBRepaymentSchedule=" + sCBRepaymentSchedule + ", additionalProperties=" + additionalProperties
				+ "]";
	}

}
