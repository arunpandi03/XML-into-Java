
package com.az.model;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "domainName",
    "subDomainName"
})

public class SenderDomain {

    @JsonProperty("domainName")
    private String domainName;
    @JsonProperty("subDomainName")
    private SubDomainName subDomainName;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public SenderDomain() {
    }

    /**
     * 
     * @param domainName
     * @param subDomainName
     */
    public SenderDomain(String domainName, SubDomainName subDomainName) {
        super();
        this.domainName = domainName;
        this.subDomainName = subDomainName;
    }

    @JsonProperty("domainName")
    public String getDomainName() {
        return domainName;
    }

    @JsonProperty("domainName")
    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    public SenderDomain withDomainName(String domainName) {
        this.domainName = domainName;
        return this;
    }

    @JsonProperty("subDomainName")
    public SubDomainName getSubDomainName() {
        return subDomainName;
    }

    @JsonProperty("subDomainName")
    public void setSubDomainName(SubDomainName subDomainName) {
        this.subDomainName = subDomainName;
    }

    public SenderDomain withSubDomainName(SubDomainName subDomainName) {
        this.subDomainName = subDomainName;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public SenderDomain withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

	@Override
	public String toString() {
		return "SenderDomain [domainName=" + domainName + ", subDomainName=" + subDomainName + ", additionalProperties="
				+ additionalProperties + "]";
	}

}
