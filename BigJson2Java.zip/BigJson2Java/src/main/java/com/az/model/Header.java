package com.az.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "messageDetails",
    "originationDetails",
    "captureSystem",
    "process"
})

public class Header {

    @JsonProperty("messageDetails")
    private MessageDetails messageDetails;
    @JsonProperty("originationDetails")
    private OriginationDetails originationDetails;
    @JsonProperty("captureSystem")
    private String captureSystem;
    @JsonProperty("process")
    private Process process;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public Header() {
    }

    /**
     * 
     * @param captureSystem
     * @param process
     * @param messageDetails
     * @param originationDetails
     */
    public Header(MessageDetails messageDetails, OriginationDetails originationDetails, String captureSystem, Process process) {
        super();
        this.messageDetails = messageDetails;
        this.originationDetails = originationDetails;
        this.captureSystem = captureSystem;
        this.process = process;
    }

    @JsonProperty("messageDetails")
    public MessageDetails getMessageDetails() {
        return messageDetails;
    }

    @JsonProperty("messageDetails")
    public void setMessageDetails(MessageDetails messageDetails) {
        this.messageDetails = messageDetails;
    }

    public Header withMessageDetails(MessageDetails messageDetails) {
        this.messageDetails = messageDetails;
        return this;
    }

    @JsonProperty("originationDetails")
    public OriginationDetails getOriginationDetails() {
        return originationDetails;
    }

    @JsonProperty("originationDetails")
    public void setOriginationDetails(OriginationDetails originationDetails) {
        this.originationDetails = originationDetails;
    }

    public Header withOriginationDetails(OriginationDetails originationDetails) {
        this.originationDetails = originationDetails;
        return this;
    }

    @JsonProperty("captureSystem")
    public String getCaptureSystem() {
        return captureSystem;
    }

    @JsonProperty("captureSystem")
    public void setCaptureSystem(String captureSystem) {
        this.captureSystem = captureSystem;
    }

    public Header withCaptureSystem(String captureSystem) {
        this.captureSystem = captureSystem;
        return this;
    }

    @JsonProperty("process")
    public Process getProcess() {
        return process;
    }

    @JsonProperty("process")
    public void setProcess(Process process) {
        this.process = process;
    }

    public Header withProcess(Process process) {
        this.process = process;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Header withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

	@Override
	public String toString() {
		return "Header [messageDetails=" + messageDetails + ", originationDetails=" + originationDetails
				+ ", captureSystem=" + captureSystem + ", process=" + process + ", additionalProperties="
				+ additionalProperties + "]";
	}

}
