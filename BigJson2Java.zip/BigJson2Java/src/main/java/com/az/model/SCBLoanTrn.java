package com.az.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "SCB_PageNum",
    "SCB_NextLoan"
})
public class SCBLoanTrn {

    @JsonProperty("SCB_PageNum")
    private Long sCBPageNum;
    @JsonProperty("SCB_NextLoan")
    private Long sCBNextLoan;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public SCBLoanTrn() {
    }

    /**
     * 
     * @param sCBPageNum
     * @param sCBNextLoan
     */
    public SCBLoanTrn(Long sCBPageNum, Long sCBNextLoan) {
        super();
        this.sCBPageNum = sCBPageNum;
        this.sCBNextLoan = sCBNextLoan;
    }

    @JsonProperty("SCB_PageNum")
    public Long getSCBPageNum() {
        return sCBPageNum;
    }

    @JsonProperty("SCB_PageNum")
    public void setSCBPageNum(Long sCBPageNum) {
        this.sCBPageNum = sCBPageNum;
    }

    public SCBLoanTrn withSCBPageNum(Long sCBPageNum) {
        this.sCBPageNum = sCBPageNum;
        return this;
    }

    @JsonProperty("SCB_NextLoan")
    public Long getSCBNextLoan() {
        return sCBNextLoan;
    }

    @JsonProperty("SCB_NextLoan")
    public void setSCBNextLoan(Long sCBNextLoan) {
        this.sCBNextLoan = sCBNextLoan;
    }

    public SCBLoanTrn withSCBNextLoan(Long sCBNextLoan) {
        this.sCBNextLoan = sCBNextLoan;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public SCBLoanTrn withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

	@Override
	public String toString() {
		return "SCBLoanTrn [sCBPageNum=" + sCBPageNum + ", sCBNextLoan=" + sCBNextLoan + ", additionalProperties="
				+ additionalProperties + "]";
	}

}
