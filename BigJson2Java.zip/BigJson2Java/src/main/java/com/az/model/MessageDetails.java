package com.az.model;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "messageVersion",
    "messageType"
})
public class MessageDetails {

    @JsonProperty("messageVersion")
    private Long messageVersion;
    @JsonProperty("messageType")
    private MessageType messageType;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public MessageDetails() {
    }

    /**
     * 
     * @param messageType
     * @param messageVersion
     */
    public MessageDetails(Long messageVersion, MessageType messageType) {
        super();
        this.messageVersion = messageVersion;
        this.messageType = messageType;
    }

    @JsonProperty("messageVersion")
    public Long getMessageVersion() {
        return messageVersion;
    }

    @JsonProperty("messageVersion")
    public void setMessageVersion(Long messageVersion) {
        this.messageVersion = messageVersion;
    }

    public MessageDetails withMessageVersion(Long messageVersion) {
        this.messageVersion = messageVersion;
        return this;
    }

    @JsonProperty("messageType")
    public MessageType getMessageType() {
        return messageType;
    }

    @JsonProperty("messageType")
    public void setMessageType(MessageType messageType) {
        this.messageType = messageType;
    }

    public MessageDetails withMessageType(MessageType messageType) {
        this.messageType = messageType;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public MessageDetails withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

	@Override
	public String toString() {
		return "MessageDetails [messageVersion=" + messageVersion + ", messageType=" + messageType
				+ ", additionalProperties=" + additionalProperties + "]";
	}

}
