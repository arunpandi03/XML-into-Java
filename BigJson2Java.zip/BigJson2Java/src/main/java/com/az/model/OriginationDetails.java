
package com.az.model;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "messageSender",
    "messageTimestamp",
    "initiatedTimestamp",
    "trackingId",
    "customSearchID",
    "possibleDuplicate"
})
public class OriginationDetails {

    @JsonProperty("messageSender")
    private MessageSender messageSender;
    @JsonProperty("messageTimestamp")
    private String messageTimestamp;
    @JsonProperty("initiatedTimestamp")
    private String initiatedTimestamp;
    @JsonProperty("trackingId")
    private String trackingId;
    @JsonProperty("customSearchID")
    private String customSearchID;
    @JsonProperty("possibleDuplicate")
    private Boolean possibleDuplicate;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public OriginationDetails() {
    }

    /**
     * 
     * @param possibleDuplicate
     * @param customSearchID
     * @param messageSender
     * @param messageTimestamp
     * @param initiatedTimestamp
     * @param trackingId
     */
    public OriginationDetails(MessageSender messageSender, String messageTimestamp, String initiatedTimestamp, String trackingId, String customSearchID, Boolean possibleDuplicate) {
        super();
        this.messageSender = messageSender;
        this.messageTimestamp = messageTimestamp;
        this.initiatedTimestamp = initiatedTimestamp;
        this.trackingId = trackingId;
        this.customSearchID = customSearchID;
        this.possibleDuplicate = possibleDuplicate;
    }

    @JsonProperty("messageSender")
    public MessageSender getMessageSender() {
        return messageSender;
    }

    @JsonProperty("messageSender")
    public void setMessageSender(MessageSender messageSender) {
        this.messageSender = messageSender;
    }

    public OriginationDetails withMessageSender(MessageSender messageSender) {
        this.messageSender = messageSender;
        return this;
    }

    @JsonProperty("messageTimestamp")
    public String getMessageTimestamp() {
        return messageTimestamp;
    }

    @JsonProperty("messageTimestamp")
    public void setMessageTimestamp(String messageTimestamp) {
        this.messageTimestamp = messageTimestamp;
    }

    public OriginationDetails withMessageTimestamp(String messageTimestamp) {
        this.messageTimestamp = messageTimestamp;
        return this;
    }

    @JsonProperty("initiatedTimestamp")
    public String getInitiatedTimestamp() {
        return initiatedTimestamp;
    }

    @JsonProperty("initiatedTimestamp")
    public void setInitiatedTimestamp(String initiatedTimestamp) {
        this.initiatedTimestamp = initiatedTimestamp;
    }

    public OriginationDetails withInitiatedTimestamp(String initiatedTimestamp) {
        this.initiatedTimestamp = initiatedTimestamp;
        return this;
    }

    @JsonProperty("trackingId")
    public String getTrackingId() {
        return trackingId;
    }

    @JsonProperty("trackingId")
    public void setTrackingId(String trackingId) {
        this.trackingId = trackingId;
    }

    public OriginationDetails withTrackingId(String trackingId) {
        this.trackingId = trackingId;
        return this;
    }

    @JsonProperty("customSearchID")
    public String getCustomSearchID() {
        return customSearchID;
    }

    @JsonProperty("customSearchID")
    public void setCustomSearchID(String customSearchID) {
        this.customSearchID = customSearchID;
    }

    public OriginationDetails withCustomSearchID(String customSearchID) {
        this.customSearchID = customSearchID;
        return this;
    }

    @JsonProperty("possibleDuplicate")
    public Boolean getPossibleDuplicate() {
        return possibleDuplicate;
    }

    @JsonProperty("possibleDuplicate")
    public void setPossibleDuplicate(Boolean possibleDuplicate) {
        this.possibleDuplicate = possibleDuplicate;
    }

    public OriginationDetails withPossibleDuplicate(Boolean possibleDuplicate) {
        this.possibleDuplicate = possibleDuplicate;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public OriginationDetails withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

	@Override
	public String toString() {
		return "OriginationDetails [messageSender=" + messageSender + ", messageTimestamp=" + messageTimestamp
				+ ", initiatedTimestamp=" + initiatedTimestamp + ", trackingId=" + trackingId + ", customSearchID="
				+ customSearchID + ", possibleDuplicate=" + possibleDuplicate + ", additionalProperties="
				+ additionalProperties + "]";
	}

}
