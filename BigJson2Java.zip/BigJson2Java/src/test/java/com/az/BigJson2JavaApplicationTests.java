package com.az;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BigJson2JavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
