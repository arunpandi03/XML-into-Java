
package com.az.model;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "AcctStatusCode",
    "StatusDesc"
})

public class AcctStatus {

    @JsonProperty("AcctStatusCode")
    private Long acctStatusCode;
    @JsonProperty("StatusDesc")
    private String statusDesc;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public AcctStatus() {
    }

    /**
     * 
     * @param statusDesc
     * @param acctStatusCode
     */
    public AcctStatus(Long acctStatusCode, String statusDesc) {
        super();
        this.acctStatusCode = acctStatusCode;
        this.statusDesc = statusDesc;
    }

    @JsonProperty("AcctStatusCode")
    public Long getAcctStatusCode() {
        return acctStatusCode;
    }

    @JsonProperty("AcctStatusCode")
    public void setAcctStatusCode(Long acctStatusCode) {
        this.acctStatusCode = acctStatusCode;
    }

    public AcctStatus withAcctStatusCode(Long acctStatusCode) {
        this.acctStatusCode = acctStatusCode;
        return this;
    }

    @JsonProperty("StatusDesc")
    public String getStatusDesc() {
        return statusDesc;
    }

    @JsonProperty("StatusDesc")
    public void setStatusDesc(String statusDesc) {
        this.statusDesc = statusDesc;
    }

    public AcctStatus withStatusDesc(String statusDesc) {
        this.statusDesc = statusDesc;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AcctStatus withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

	@Override
	public String toString() {
		return "AcctStatus [acctStatusCode=" + acctStatusCode + ", statusDesc=" + statusDesc + ", additionalProperties="
				+ additionalProperties + "]";
	}

}
