package com.az.model;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "getLoanListInquiryResponse"
})
public class Body {

    @JsonProperty("getLoanListInquiryResponse")
    private GetLoanListInquiryResponse getLoanListInquiryResponse;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public Body() {
    }

    /**
     * 
     * @param getLoanListInquiryResponse
     */
    public Body(GetLoanListInquiryResponse getLoanListInquiryResponse) {
        super();
        this.getLoanListInquiryResponse = getLoanListInquiryResponse;
    }

    @JsonProperty("getLoanListInquiryResponse")
    public GetLoanListInquiryResponse getGetLoanListInquiryResponse() {
        return getLoanListInquiryResponse;
    }

    @JsonProperty("getLoanListInquiryResponse")
    public void setGetLoanListInquiryResponse(GetLoanListInquiryResponse getLoanListInquiryResponse) {
        this.getLoanListInquiryResponse = getLoanListInquiryResponse;
    }

    public Body withGetLoanListInquiryResponse(GetLoanListInquiryResponse getLoanListInquiryResponse) {
        this.getLoanListInquiryResponse = getLoanListInquiryResponse;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Body withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

	@Override
	public String toString() {
		return "Body [getLoanListInquiryResponse=" + getLoanListInquiryResponse + ", additionalProperties="
				+ additionalProperties + "]";
	}

}
