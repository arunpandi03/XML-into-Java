package com.az.model;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Count",
    "TermUnits",
    "Desc"
})

public class Term {

    @JsonProperty("Count")
    private Long count;
    @JsonProperty("TermUnits")
    private String termUnits;
    @JsonProperty("Desc")
    private String desc;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public Term() {
    }

    /**
     * 
     * @param termUnits
     * @param count
     * @param desc
     */
    public Term(Long count, String termUnits, String desc) {
        super();
        this.count = count;
        this.termUnits = termUnits;
        this.desc = desc;
    }

    @JsonProperty("Count")
    public Long getCount() {
        return count;
    }

    @JsonProperty("Count")
    public void setCount(Long count) {
        this.count = count;
    }

    public Term withCount(Long count) {
        this.count = count;
        return this;
    }

    @JsonProperty("TermUnits")
    public String getTermUnits() {
        return termUnits;
    }

    @JsonProperty("TermUnits")
    public void setTermUnits(String termUnits) {
        this.termUnits = termUnits;
    }

    public Term withTermUnits(String termUnits) {
        this.termUnits = termUnits;
        return this;
    }

    @JsonProperty("Desc")
    public String getDesc() {
        return desc;
    }

    @JsonProperty("Desc")
    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Term withDesc(String desc) {
        this.desc = desc;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Term withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

	@Override
	public String toString() {
		return "Term [count=" + count + ", termUnits=" + termUnits + ", desc=" + desc + ", additionalProperties="
				+ additionalProperties + "]";
	}

}
