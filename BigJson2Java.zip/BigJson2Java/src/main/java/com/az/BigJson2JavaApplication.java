package com.az;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BigJson2JavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BigJson2JavaApplication.class, args);
	}

}
