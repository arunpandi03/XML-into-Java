package com.az.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "CurCode",
    "AcctIdent",
    "Term",
    "MaturityDt",
    "TaxCountry",
    "AcctType",
    "AcctBal",
    "AcctPeriodData",
    "Ownership",
    "RemainingPmtCount",
    "Segmentation",
    "SCBLoanApplication"
})

public class AcctInfo {

    @JsonProperty("CurCode")
    private CurCode curCode;
    @JsonProperty("AcctIdent")
    private AcctIdent acctIdent;
    @JsonProperty("Term")
    private Term term;
    @JsonProperty("MaturityDt")
    private String maturityDt;
    @JsonProperty("TaxCountry")
    private TaxCountry taxCountry;
    @JsonProperty("AcctType")
    private AcctType acctType;
    @JsonProperty("AcctBal")
    private List<AcctBal> acctBal = null;
    @JsonProperty("AcctPeriodData")
    private List<AcctPeriodDatum> acctPeriodData = null;
    @JsonProperty("Ownership")
    private String ownership;
    @JsonProperty("RemainingPmtCount")
    private Long remainingPmtCount;
    @JsonProperty("Segmentation")
    private Segmentation segmentation;
    @JsonProperty("SCBLoanApplication")
    private SCBLoanApplication sCBLoanApplication;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public AcctInfo() {
    }

    /**
     * 
     * @param sCBLoanApplication
     * @param ownership
     * @param remainingPmtCount
     * @param acctPeriodData
     * @param acctType
     * @param taxCountry
     * @param segmentation
     * @param term
     * @param maturityDt
     * @param curCode
     * @param acctIdent
     * @param acctBal
     */
    public AcctInfo(CurCode curCode, AcctIdent acctIdent, Term term, String maturityDt, TaxCountry taxCountry, AcctType acctType, List<AcctBal> acctBal, List<AcctPeriodDatum> acctPeriodData, String ownership, Long remainingPmtCount, Segmentation segmentation, SCBLoanApplication sCBLoanApplication) {
        super();
        this.curCode = curCode;
        this.acctIdent = acctIdent;
        this.term = term;
        this.maturityDt = maturityDt;
        this.taxCountry = taxCountry;
        this.acctType = acctType;
        this.acctBal = acctBal;
        this.acctPeriodData = acctPeriodData;
        this.ownership = ownership;
        this.remainingPmtCount = remainingPmtCount;
        this.segmentation = segmentation;
        this.sCBLoanApplication = sCBLoanApplication;
    }

    @JsonProperty("CurCode")
    public CurCode getCurCode() {
        return curCode;
    }

    @JsonProperty("CurCode")
    public void setCurCode(CurCode curCode) {
        this.curCode = curCode;
    }

    public AcctInfo withCurCode(CurCode curCode) {
        this.curCode = curCode;
        return this;
    }

    @JsonProperty("AcctIdent")
    public AcctIdent getAcctIdent() {
        return acctIdent;
    }

    @JsonProperty("AcctIdent")
    public void setAcctIdent(AcctIdent acctIdent) {
        this.acctIdent = acctIdent;
    }

    public AcctInfo withAcctIdent(AcctIdent acctIdent) {
        this.acctIdent = acctIdent;
        return this;
    }

    @JsonProperty("Term")
    public Term getTerm() {
        return term;
    }

    @JsonProperty("Term")
    public void setTerm(Term term) {
        this.term = term;
    }

    public AcctInfo withTerm(Term term) {
        this.term = term;
        return this;
    }

    @JsonProperty("MaturityDt")
    public String getMaturityDt() {
        return maturityDt;
    }

    @JsonProperty("MaturityDt")
    public void setMaturityDt(String maturityDt) {
        this.maturityDt = maturityDt;
    }

    public AcctInfo withMaturityDt(String maturityDt) {
        this.maturityDt = maturityDt;
        return this;
    }

    @JsonProperty("TaxCountry")
    public TaxCountry getTaxCountry() {
        return taxCountry;
    }

    @JsonProperty("TaxCountry")
    public void setTaxCountry(TaxCountry taxCountry) {
        this.taxCountry = taxCountry;
    }

    public AcctInfo withTaxCountry(TaxCountry taxCountry) {
        this.taxCountry = taxCountry;
        return this;
    }

    @JsonProperty("AcctType")
    public AcctType getAcctType() {
        return acctType;
    }

    @JsonProperty("AcctType")
    public void setAcctType(AcctType acctType) {
        this.acctType = acctType;
    }

    public AcctInfo withAcctType(AcctType acctType) {
        this.acctType = acctType;
        return this;
    }

    @JsonProperty("AcctBal")
    public List<AcctBal> getAcctBal() {
        return acctBal;
    }

    @JsonProperty("AcctBal")
    public void setAcctBal(List<AcctBal> acctBal) {
        this.acctBal = acctBal;
    }

    public AcctInfo withAcctBal(List<AcctBal> acctBal) {
        this.acctBal = acctBal;
        return this;
    }

    @JsonProperty("AcctPeriodData")
    public List<AcctPeriodDatum> getAcctPeriodData() {
        return acctPeriodData;
    }

    @JsonProperty("AcctPeriodData")
    public void setAcctPeriodData(List<AcctPeriodDatum> acctPeriodData) {
        this.acctPeriodData = acctPeriodData;
    }

    public AcctInfo withAcctPeriodData(List<AcctPeriodDatum> acctPeriodData) {
        this.acctPeriodData = acctPeriodData;
        return this;
    }

    @JsonProperty("Ownership")
    public String getOwnership() {
        return ownership;
    }

    @JsonProperty("Ownership")
    public void setOwnership(String ownership) {
        this.ownership = ownership;
    }

    public AcctInfo withOwnership(String ownership) {
        this.ownership = ownership;
        return this;
    }

    @JsonProperty("RemainingPmtCount")
    public Long getRemainingPmtCount() {
        return remainingPmtCount;
    }

    @JsonProperty("RemainingPmtCount")
    public void setRemainingPmtCount(Long remainingPmtCount) {
        this.remainingPmtCount = remainingPmtCount;
    }

    public AcctInfo withRemainingPmtCount(Long remainingPmtCount) {
        this.remainingPmtCount = remainingPmtCount;
        return this;
    }

    @JsonProperty("Segmentation")
    public Segmentation getSegmentation() {
        return segmentation;
    }

    @JsonProperty("Segmentation")
    public void setSegmentation(Segmentation segmentation) {
        this.segmentation = segmentation;
    }

    public AcctInfo withSegmentation(Segmentation segmentation) {
        this.segmentation = segmentation;
        return this;
    }

    @JsonProperty("SCBLoanApplication")
    public SCBLoanApplication getSCBLoanApplication() {
        return sCBLoanApplication;
    }

    @JsonProperty("SCBLoanApplication")
    public void setSCBLoanApplication(SCBLoanApplication sCBLoanApplication) {
        this.sCBLoanApplication = sCBLoanApplication;
    }

    public AcctInfo withSCBLoanApplication(SCBLoanApplication sCBLoanApplication) {
        this.sCBLoanApplication = sCBLoanApplication;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AcctInfo withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

	@Override
	public String toString() {
		return "AcctInfo [curCode=" + curCode + ", acctIdent=" + acctIdent + ", term=" + term + ", maturityDt="
				+ maturityDt + ", taxCountry=" + taxCountry + ", acctType=" + acctType + ", acctBal=" + acctBal
				+ ", acctPeriodData=" + acctPeriodData + ", ownership=" + ownership + ", remainingPmtCount="
				+ remainingPmtCount + ", segmentation=" + segmentation + ", sCBLoanApplication=" + sCBLoanApplication
				+ ", additionalProperties=" + additionalProperties + "]";
	}

}
