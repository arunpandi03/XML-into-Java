
package com.az.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "AcctIdentType",
    "AcctIdentValue"
})

public class AcctIdent {

    @JsonProperty("AcctIdentType")
    private String acctIdentType;
    @JsonProperty("AcctIdentValue")
    private Long acctIdentValue;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public AcctIdent() {
    }

    /**
     * 
     * @param acctIdentValue
     * @param acctIdentType
     */
    public AcctIdent(String acctIdentType, Long acctIdentValue) {
        super();
        this.acctIdentType = acctIdentType;
        this.acctIdentValue = acctIdentValue;
    }

    @JsonProperty("AcctIdentType")
    public String getAcctIdentType() {
        return acctIdentType;
    }

    @JsonProperty("AcctIdentType")
    public void setAcctIdentType(String acctIdentType) {
        this.acctIdentType = acctIdentType;
    }

    public AcctIdent withAcctIdentType(String acctIdentType) {
        this.acctIdentType = acctIdentType;
        return this;
    }

    @JsonProperty("AcctIdentValue")
    public Long getAcctIdentValue() {
        return acctIdentValue;
    }

    @JsonProperty("AcctIdentValue")
    public void setAcctIdentValue(Long acctIdentValue) {
        this.acctIdentValue = acctIdentValue;
    }

    public AcctIdent withAcctIdentValue(Long acctIdentValue) {
        this.acctIdentValue = acctIdentValue;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public AcctIdent withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

	@Override
	public String toString() {
		return "AcctIdent [acctIdentType=" + acctIdentType + ", acctIdentValue=" + acctIdentValue
				+ ", additionalProperties=" + additionalProperties + "]";
	}

}
