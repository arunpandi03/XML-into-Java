package com.az.controller;

import java.nio.file.Files;
import java.nio.file.Paths;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.az.model.Json2Pojo;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping(value = { "/demo1", "/demo", "welcome" })
public class JsconController {

	@Autowired
	Environment env;

	@GetMapping("/json2java")

	public Json2Pojo run() {
		Json2Pojo result = null;
		try {
			byte[] arr = Files.readAllBytes(Paths.get("D:\\arun\\JSON.txt"));

			ObjectMapper objmap = new ObjectMapper();

			result = objmap.readValue(arr, Json2Pojo.class);

			System.out.println(result);
			// return result;
		} catch (Exception e1) {
			e1.printStackTrace();
		}

		return result;
	}

	@GetMapping("/getAswin")
	public ResponseEntity<?> print() {
		Json2Pojo output = null;
		try {
			System.out.println("Executing restmenuname!!");
			RestTemplate restTemplate = new RestTemplate();
			String url = env.getProperty("url");
			output = restTemplate.getForObject(url, Json2Pojo.class);
			System.out.println(output);

		} catch (Exception e) {
			System.out.println(e);
		}
		return new ResponseEntity<>(output, HttpStatus.OK);

	}

	@GetMapping("/http")

	public ResponseEntity<?> go() {
		DefaultHttpClient httpClient = new DefaultHttpClient();
		String apiOutput = null;
		try {
			HttpGet getRequest = new HttpGet("http://172.16.11.157:8080/gets");
			HttpResponse response = httpClient.execute(getRequest);
			HttpEntity httpEntity = response.getEntity();
			apiOutput = EntityUtils.toString(httpEntity);
			System.out.println(apiOutput);
			return new ResponseEntity<>(apiOutput, HttpStatus.OK);
		} catch (Exception e1) {
			e1.printStackTrace();
		} finally {

			httpClient.getConnectionManager().shutdown();
		}

		return new ResponseEntity<>(apiOutput, HttpStatus.OK);
	}

}

@RestController
@RequestMapping("/demo2")
class JsconCont {

	@GetMapping("/json2")

	public ResponseEntity<?> execute() {
		Json2Pojo result = null;
		try {
			byte[] arr = Files.readAllBytes(Paths.get("D:\\arun\\JSON.txt"));

			ObjectMapper objmap = new ObjectMapper();

			result = objmap.readValue(arr, Json2Pojo.class);

			System.out.println(result);
			return new ResponseEntity<>(result, HttpStatus.OK);
		} catch (Exception e1) {
			e1.printStackTrace();
		}

		return new ResponseEntity<>(result, HttpStatus.OK);
	}

}